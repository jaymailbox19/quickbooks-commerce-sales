import { Component, EventEmitter, Input, Output, OnChanges, SimpleChanges } from '@angular/core';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import type { ForecastResult } from '../../services/sales';
import { ProductForecastPanel } from '../product-forecast-panel/product-forecast-panel';

import { BaseChartDirective } from 'ng2-charts';
import {
  ChartConfiguration,
  Chart,
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
} from 'chart.js';

Chart.register(
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip
);

@Component({
    selector: 'app-forecast-panel',
    standalone: true,
    imports: [CurrencyPipe, DatePipe, FormsModule, BaseChartDirective, ProductForecastPanel],
    templateUrl: './forecast-panel.html',
    styleUrl: './forecast-panel.css'
})
export class ForecastPanel implements OnChanges {
    @Input() categoryOptions: string[] = [];
    @Input() selectedCategory = '';
    @Input() selectedPeriod = 'WEEK';
    @Input() loading = false;
    @Input() error = '';
    @Input() forecast: ForecastResult | null = null;

    @Output() categoryChange = new EventEmitter<string>();
    @Output() periodChange = new EventEmitter<string>();
    @Output() forecastRequested = new EventEmitter<void>();

    public forecastChartType: 'bar' = 'bar';

    ngOnChanges(changes: SimpleChanges): void {
  if (changes['forecast']) {
    const actuals = this.forecast?.historicalActuals ?? [];
    const predictions = this.forecast?.weeklyPredictions ?? [];

    this.forecastChartData = {
      labels: [
        ...actuals.map(item => item.week),
        ...predictions.map(item => item.week)
      ],
      datasets: [
        {
          label: 'Actual Sales',
          data: [
            ...actuals.map(item => item.actualSales),
            ...predictions.map(() => null)
          ],
          backgroundColor: '#16a34a'
        },
        {
          label: 'Forecast Sales',
          data: [
            ...actuals.map(() => null),
            ...predictions.map(item => item.predictedSales)
          ],
          backgroundColor: '#3b82f6'
        }
      ]
    };
  }
}

    public forecastChartData: ChartConfiguration<'bar'>['data'] = {
        labels: [],
        datasets: [
            {
                label: 'Predicted Sales',
                data: [],
                backgroundColor: '#3b82f6'
            }
        ]
    };

    public forecastChartOptions: ChartConfiguration<'bar'>['options'] = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };
}