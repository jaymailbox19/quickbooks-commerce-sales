import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { vi } from 'vitest';

import { Dashboard } from './dashboard';
import { SalesService } from '../services/sales';
import { AuthService } from '../services/auth.service';

describe('Dashboard', () => {
  let fixture: ComponentFixture<Dashboard>;
  let component: Dashboard;

  let salesService: {
    getSalesByCategoryDateRange: ReturnType<typeof vi.fn>;
    getForecast: ReturnType<typeof vi.fn>;
    getBacktestComparison: ReturnType<typeof vi.fn>;
    getDailySalesByCategory: ReturnType<typeof vi.fn>;
    getTopProducts: ReturnType<typeof vi.fn>;
  };

  let authService: {
    getUsername: ReturnType<typeof vi.fn>;
    logout: ReturnType<typeof vi.fn>;
  };

  let router: {
    navigate: ReturnType<typeof vi.fn>;
  };

  const salesData = [
    { category: 'Electronics', totalSales: 500 },
    { category: 'Furniture', totalSales: 300 }
  ];

  const forecastData = {
    category: 'Electronics',
    predictedSales: 600,
    historicalThroughDate: '2026-09-20',
    weeklyPredictions: [
      { week: '2026-09-21', predictedSales: 600 }
    ],
    historicalActuals: [
      { week: '2026-09-14', actualSales: 550 }
    ],
    productForecasts:[]
  };

  beforeEach(async () => {
    salesService = {
      getSalesByCategoryDateRange: vi.fn(),
      getForecast: vi.fn(),
      getBacktestComparison: vi.fn(),
      getDailySalesByCategory: vi.fn(),
      getTopProducts: vi.fn()
    };

    authService = {
      getUsername: vi.fn(),
      logout: vi.fn()
    };

    router = {
      navigate: vi.fn()
    };

    // Default successful responses
    salesService.getSalesByCategoryDateRange.mockReturnValue(of(salesData));
    salesService.getTopProducts.mockReturnValue(of([]));
    salesService.getForecast.mockReturnValue(of(forecastData));
    salesService.getBacktestComparison.mockReturnValue(of([]));
    salesService.getDailySalesByCategory.mockReturnValue(of([]));

    authService.getUsername.mockReturnValue('Jay');

    await TestBed.configureTestingModule({
      imports: [Dashboard],
      providers: [
        { provide: SalesService, useValue: salesService },
        { provide: AuthService, useValue: authService },
        { provide: Router, useValue: router }
      ]
    })
      // These tests focus on Dashboard class behavior, not child components.
      .overrideComponent(Dashboard, {
        set: { template: '' }
      })
      .compileComponents();

    fixture = TestBed.createComponent(Dashboard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the dashboard', () => {
    expect(component).toBeTruthy();
  });

  it('should load sales and top products on initialization', () => {
    expect(
      salesService.getSalesByCategoryDateRange
    ).toHaveBeenCalledWith(
      component.startDate,
      component.endDate
    );

    expect(salesService.getTopProducts).toHaveBeenCalled();

    expect(component.sales()).toEqual(salesData);
    expect(component.loading()).toBe(false);
    expect(component.loggedInUsername).toBe('Jay');
  });

  it('should display an error when sales loading fails', () => {
    salesService.getSalesByCategoryDateRange.mockReturnValue(
      throwError(() => new Error('API error'))
    );

    // Trigger the request again with the error response.
    component.loadSalesByDateRange();

    expect(component.error()).toBe(
      'Unable to load sales for the selected dates.'
    );
    expect(component.loading()).toBe(false);
  });

  it('should not request sales when either date is missing', () => {
    salesService.getSalesByCategoryDateRange.mockClear();

    component.startDate = '';
    component.endDate = '2026-09-20';

    component.loadSalesByDateRange();

    expect(component.error()).toBe(
      'Please select both start and end dates.'
    );
    expect(
      salesService.getSalesByCategoryDateRange
    ).not.toHaveBeenCalled();
  });

  it('should not request sales when start date is after end date', () => {
    salesService.getSalesByCategoryDateRange.mockClear();

    component.startDate = '2026-09-20';
    component.endDate = '2026-09-10';

    component.loadSalesByDateRange();

    expect(component.error()).toBe(
      'Start date must be before or equal to end date.'
    );
    expect(
      salesService.getSalesByCategoryDateRange
    ).not.toHaveBeenCalled();
  });

  it('should filter sales by selected category', () => {
    component.sales.set(salesData);
    component.salesSearchCategory.set('Electronics');

    expect(component.filteredSales()).toEqual([
      { category: 'Electronics', totalSales: 500 }
    ]);
  });

  it('should return all sales when category is ALL', () => {
    component.sales.set(salesData);
    component.salesSearchCategory.set('ALL');

    expect(component.filteredSales()).toEqual(salesData);
  });

  it('should load forecast successfully', () => {
    component.selectedCategory = 'Electronics';
    component.selectedPeriod = 'WEEK';

    component.loadForecast();

    expect(salesService.getForecast).toHaveBeenCalledWith(
      'Electronics',
      'WEEK'
    );
    expect(component.forecast()).toEqual(forecastData);
    expect(component.forecastLoading()).toBe(false);
    expect(component.forecastError()).toBe('');
  });

  it('should show an error when forecast loading fails', () => {
    salesService.getForecast.mockReturnValue(
      throwError(() => new Error('Forecast API error'))
    );

    component.loadForecast();

    expect(component.forecastError()).toBe(
      'Unable to load forecast.'
    );
    expect(component.forecastLoading()).toBe(false);
  });

  it('should clear the forecast when requested', () => {
    component.forecast.set(forecastData);
    component.forecastError.set('Previous error');

    component.clearForecast();

    expect(component.forecast()).toBeNull();
    expect(component.forecastError()).toBe('');
  });

  it('should request daily sales for the selected category and dates', () => {
    component.startDate = '2026-09-01';
    component.endDate = '2026-09-20';

    component.openDailySales('Electronics');

    expect(
      salesService.getDailySalesByCategory
    ).toHaveBeenCalledWith(
      'Electronics',
      '2026-09-01',
      '2026-09-20'
    );

    expect(component.selectedDailyCategory()).toBe('Electronics');
    expect(component.showDailySales()).toBe(true);
    expect(component.dailySalesLoading()).toBe(false);
  });

  it('should close the daily sales panel', () => {
    component.showDailySales.set(true);

    component.closeDailySales();

    expect(component.showDailySales()).toBe(false);
  });

  it('should log out and navigate to login', () => {
    component.logout();

    expect(authService.logout).toHaveBeenCalled();
    expect(router.navigate).toHaveBeenCalledWith(['/login']);
  });
});