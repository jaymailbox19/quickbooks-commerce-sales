import { Component, OnInit, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { SalesService, CategorySales, ForecastResult, BacktestComparisonResult, DailyCategorySales, ProductSalesRanking } from '../services/sales';
import {
  LucideUserRound,
  LucideLogOut
} from '@lucide/angular';

import {
  BACKTEST_COLUMN_DEFS,
  DAILY_SALES_COLUMN_DEFS,
  DEFAULT_COL_DEF
} from './dashboard-grid.config';
import { getDefaultDateRange } from './dashboard-date.utils';
import {
  calculateMae,
  calculateMaeDifference,
  findTopSellingCategory,
  getCategoryOptions
} from './dashboard-metrics.utils';
import { DailySalesPanel } from './daily-sales-panel/daily-sales-panel';
import { ForecastPanel } from './forecast-panel/forecast-panel';
import { TopProductsPanel } from './top-products-panel/top-products-panel';

import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

import { AgGridAngular } from 'ag-grid-angular';
import {
  AllCommunityModule,
  ModuleRegistry,
  themeAlpine
} from 'ag-grid-community';

ModuleRegistry.registerModules([AllCommunityModule]);

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CurrencyPipe, DatePipe, FormsModule, AgGridAngular,
    LucideUserRound, LucideLogOut, DailySalesPanel, ForecastPanel, TopProductsPanel],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {

  columnDefs = BACKTEST_COLUMN_DEFS;
  dailySalesColumnDefs = DAILY_SALES_COLUMN_DEFS;
  defaultColDef = DEFAULT_COL_DEF;
  sales = signal<CategorySales[]>([]);
  loading = signal(true);
  error = signal('');
  forecast = signal<ForecastResult | null>(null);
  forecastLoading = signal(false);
  forecastError = signal('');
  comparison = signal<BacktestComparisonResult[]>([]);
  comparisonLoading = signal(false);
  comparisonError = signal('');
  selectedCategory = 'Electronics';
  selectedPeriod = 'WEEK';

  startDate = '';
  endDate = '';

  dailySales = signal<DailyCategorySales[]>([]);
  dailySalesLoading = signal(false);
  dailySalesError = signal('');
  selectedDailyCategory = signal('');
  showDailySales = signal(false);

  topProducts = signal<ProductSalesRanking[]>([]);
  topProductsLoading = signal(false);
  topProductsError = signal('');

  salesSearchCategory = signal('ALL');
  categoryOptions: string[] = [];
  filteredSales = computed(() => {
    const rows = this.sales();
    const category = this.salesSearchCategory();

    if (category === 'ALL') {
      return rows;
    }

    return rows.filter(item => item.category === category);
  });

  movingAverageMae = computed(() =>
    calculateMae(this.comparison(), 'movingAverageError')
  );

  xgboostMae = computed(() =>
    calculateMae(this.comparison(), 'xgboostError')
  );

  maeDifference = computed(() =>
    calculateMaeDifference(
      this.movingAverageMae(),
      this.xgboostMae()
    )
  );

  topSellingCategory = computed(() =>
    findTopSellingCategory(this.sales())
  );

  themeAlpine = themeAlpine;
  paginationPageSize = 10;
  paginationPageSizeSelector: number[] | boolean = [10, 20, 50, 100];
  loggedInUsername: string | undefined;


  constructor(
    private salesService: SalesService,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loggedInUsername = this.authService.getUsername() ?? '';
    const dateRange = getDefaultDateRange();
    this.startDate = dateRange.startDate;
    this.endDate = dateRange.endDate;
    this.loadTopProducts();
    this.salesService.getSalesByCategoryDateRange(this.startDate, this.endDate).subscribe({
      next: (data) => {
        this.sales.set(data);
        this.updateCategoryOptions(data);
        this.loading.set(false);
      },
      error: (err) => {
        console.error('Sales API error:', err);
        this.error.set('Unable to load sales data.');
        this.loading.set(false);
      }
    });
  }

  loadForecast(): void {
    this.forecastLoading.set(true);
    this.forecastError.set('');
    this.forecast.set(null);

    this.salesService
      .getForecast(this.selectedCategory, this.selectedPeriod)
      .subscribe({
        next: (result) => {
          this.forecast.set(result);
          this.forecastLoading.set(false);
        },
        error: (err) => {
          console.error('Forecast API error:', err);
          this.forecastError.set('Unable to load forecast.');
          this.forecastLoading.set(false);
        }
      });
  }

  loadComparison(): void {
    this.comparisonLoading.set(true);
    this.comparisonError.set('');

    this.salesService.getBacktestComparison().subscribe({
      next: data => {
        this.comparison.set(data);
        this.comparisonLoading.set(false);
      },
      error: err => {
        console.error('Backtest comparison API error:', err);
        this.comparisonError.set('Unable to load model comparison.');
        this.comparisonLoading.set(false);
      }
    });
  }

  loadSalesByDateRange(): void {
    if (!this.startDate || !this.endDate) {
      this.error.set('Please select both start and end dates.');
      return;
    }

    if (this.startDate > this.endDate) {
      this.error.set('Start date must be before or equal to end date.');
      return;
    }
    this.loadTopProducts();
    this.loading.set(true);
    this.error.set('');

    this.salesService
      .getSalesByCategoryDateRange(this.startDate, this.endDate, this.salesSearchCategory())
      .subscribe({
        next: data => {
          this.sales.set(data);
          this.loading.set(false);
        },
        error: err => {
          console.error('Date-range sales API error:', err);
          this.error.set('Unable to load sales for the selected dates.');
          this.loading.set(false);
        }
      });
  }

  openDailySales(category: string): void {
    if (!this.startDate || !this.endDate) {
      this.error.set('Select a date range first.');
      return;
    }

    this.selectedDailyCategory.set(category);
    this.showDailySales.set(true);
    this.dailySalesLoading.set(true);
    this.dailySalesError.set('');
    this.dailySales.set([]);

    this.salesService
      .getDailySalesByCategory(category, this.startDate, this.endDate)
      .subscribe({
        next: data => {
          this.dailySales.set(data);
          this.dailySalesLoading.set(false);
        },
        error: err => {
          console.error('Daily sales API error:', err);
          this.dailySalesError.set('Unable to load daily sales.');
          this.dailySalesLoading.set(false);
        }
      });
  }
loadTopProducts(): void {
  if (!this.startDate || !this.endDate) {
    this.topProducts.set([]);
    this.topProductsLoading.set(false);
    this.topProductsError.set('Please select both start and end dates.');
    return;
  }

  if (this.startDate > this.endDate) {
    this.topProducts.set([]);
    this.topProductsLoading.set(false);
    this.topProductsError.set('Start date must be before or equal to end date.');
    return;
  }
  const selectedCategory = this.salesSearchCategory();
  const category =
  !selectedCategory || selectedCategory === 'ALL'
    ? undefined
    : selectedCategory;

  this.topProductsLoading.set(true);
  this.topProductsError.set('');
  this.topProducts.set([]);

  this.salesService.getTopProducts(this.startDate, this.endDate, category).subscribe({
    next: data => {
      this.topProducts.set(data);
      this.topProductsLoading.set(false);
    },
    error: err => {
      console.error('Top products API error:', err);
      this.topProductsError.set('Unable to load top-selling products.');
      this.topProductsLoading.set(false);
    }
  });
}
  closeDailySales(): void {
    this.showDailySales.set(false);
  }
  clearForecast() {
    this.forecast.set(null);
    this.forecastError.set('');
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  private updateCategoryOptions(data: CategorySales[]): void {
    this.categoryOptions = getCategoryOptions(data);
  }

}